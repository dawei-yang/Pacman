﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;


public class Pacman : MonoBehaviour {
	static public Pacman P;
	public bool enableRight = true;
	public bool enableLeft = true;
	public bool enableUp = true;
	public bool enableDown = true;

	public int moveDirection = 0;


	[Header("Set in Inspector")]
	public float speed = 1f;

	void Start () {
        if (P == null)
		{
            P = this;	
		}
		else
		{
			Debug.LogError("Pecman.Awake() - Attempted to assign second Pecman.P!");
		}
	}
	
	// Update is called once per frame
	void Update () {
		move ();


	}

	public void OnTriggerEnter (Collider other)
	{
		if (other.gameObject.tag == "Ghost") {
            Destroy (this.gameObject);
		}
		if (other.gameObject.tag == "WeakGhost") {
			Destroy (other.gameObject);
		}
	}

    public void move(){
		if (Input.GetKeyDown ("down")) {
			moveDirection = 3;
		}
		if (Input.GetKeyDown ("up")) {
			moveDirection = 1;
		}
		if (Input.GetKeyDown ("left")) {
			moveDirection = 2;
		}
		if (Input.GetKeyDown ("right")) {
			moveDirection = 4;
		}

		if (moveDirection == 3) {
			Vector3 pos = transform.position;
			pos.y -= speed * Time.deltaTime;
			transform.position = pos;
		}
		if (moveDirection == 1) {
			Vector3 pos = transform.position;
			pos.y += speed * Time.deltaTime;
			transform.position = pos;
		}
		if (moveDirection == 2) {
			Vector3 pos = transform.position;
			pos.x -= speed * Time.deltaTime;
			transform.position = pos;
		}
		if (moveDirection == 4) {
			Vector3 pos = transform.position;
			pos.x += speed * Time.deltaTime;
			transform.position = pos;
		}
	}


}
