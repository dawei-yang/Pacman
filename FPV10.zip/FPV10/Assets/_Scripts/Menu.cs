﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Menu : MonoBehaviour {
	[Header("Set in Inspector")]
	public Text uitMenuLevelOne;
	public Text uitMenuLevelTwo;
	public Text uitMenuLevelThree;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		UpdateHighest ();
	}


	public void UpdateHighest()
	{
		if (!PlayerPrefs.HasKey ("LevelOneHighest")) {
			uitMenuLevelOne.text = "Level 1: No Record";
		} else {
			uitMenuLevelOne.text = "Level 1: " + PlayerPrefs.GetInt ("LevelOneHighest").ToString();
		}

		if (!PlayerPrefs.HasKey ("LevelTwoHighest")) {
			uitMenuLevelTwo.text = "Level 2: No Record";
		} else {
			uitMenuLevelTwo.text = "Level 2: " + PlayerPrefs.GetInt ("LevelTwoHighest").ToString();
		}

		if (!PlayerPrefs.HasKey ("LevelThreeHighest")) {
			uitMenuLevelThree.text = "Level 3 : No Record";
		} else {
			uitMenuLevelThree.text = "Level 3: " + PlayerPrefs.GetInt ("LevelThreeHighest").ToString();
		}
	}

}
