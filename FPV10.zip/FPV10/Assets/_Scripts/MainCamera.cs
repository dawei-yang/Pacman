﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public enum States{
	 nothing,
	 eatcubedot,
	 eatyellowdot,
     dead
};


public class MainCamera : MonoBehaviour
{
    static public MainCamera M;
    public static States CurrentState = States.nothing;
    public delegate void PecmanEatsDot();
    public static event PecmanEatsDot OnPecmanEatBlueDot;
    public static event PecmanEatsDot OnPecmanEatYellowDot;
    public static int Score = 0;
    public static int level = 1;

    [Header("Set in Inspector")]
    public Text uitTotalScore;
    public Text uitHighestScore;
    public Text uitLife;



    public GameObject pacman;
    public GameObject dot;
    public GameObject[] prefabPickups;
    public Vector3[] spawnPoints;
    public float pickupSpawnPerSecond = 0.5f;
    static public bool IsFreezed = false;
    static public bool IsBlue = false;
    static public bool IsYellow = false;
    public int life = 3;

    private void Awake()
    {
        M = this;
        UpdateHighest();
       // Invoke("SpawnPickup", 1f / pickupSpawnPerSecond);
    }

    // Use this for initialization
    void Start()
    {
		
        UpdateHighest();
        GetCurrentScene();
        SpawnPacman();
        SpawnDots();
        SpawnPickup();

        OnPecmanEatBlueDot = TurnBlue;
        OnPecmanEatBlueDot += SetDefault;
        OnPecmanEatBlueDot += Freezed;
        OnPecmanEatYellowDot = TurnYellow;
        OnPecmanEatYellowDot += SetDefault;
    }

    // Update is called once per frame
    void Update()
    {
		//----------
	
	//	UpdateMainMenu ();
		//---------
        GetCurrentScene();
		UpdateGUI ();
        if (CurrentState == States.eatcubedot) OnPecmanEatBlueDot();
        if (CurrentState == States.eatyellowdot) OnPecmanEatYellowDot();
        GameObject[] checkDots = GameObject.FindGameObjectsWithTag("Dot");
        GameObject[] checkFruit = GameObject.FindGameObjectsWithTag("Fruit");
        GameObject[] checkPacman = GameObject.FindGameObjectsWithTag("Pacman");

		if (checkPacman.Length == 0) {
			SpawnPacman ();

		}

        if (checkDots.Length <= 196 - 136 && checkFruit.Length == 0)
        {
            LevelUp();
        }
    }

    public void SpawnPacman()
    {
        if (life > 0)
        {
            GameObject go = Instantiate<GameObject>(pacman);
            go.SetActive(false);
            Vector3 pos = Vector3.zero;
            pos.x = 0f;
            pos.y = -0.571f;
            go.transform.position = pos;
            life--;
            go.SetActive(true);
        }
        else
        {
			
            RecordHighest();
            SceneManager.LoadScene("End");
        }
    }

    // spawn a random pickup from list.
    // spawn position random from array of Vector3
    public void SpawnPickup()
    {
        int indexPrefab = Random.Range(0, prefabPickups.Length);
        int indexSpawn = Random.Range(0, spawnPoints.Length);
        GameObject go = Instantiate<GameObject>(prefabPickups[indexPrefab]);

        Vector3 pos = Vector3.zero;
        pos.x = spawnPoints[indexSpawn].x;
        pos.y = spawnPoints[indexSpawn].y;
        go.transform.position = pos;

        Invoke("SpawnPickup", 1f / pickupSpawnPerSecond);
    }

    public void SpawnDots()
    {
        float x = -3.29f;
        float y = 4.49f;
        Vector3 pos, pos2;
        GameObject go, go2;

        //132 dots are actually relavent
        for (int j = 0; j < 16; j++)
        {
            for (int i = 0; i < 6; i++)
            {
                go = Instantiate<GameObject>(dot);
                go2 = Instantiate<GameObject>(dot);
                pos = pos2 = Vector3.zero;
                pos.x = x + 0.58f * i;
                pos2.x = -pos.x;
                pos.y = y - 0.61f * j;
                pos2.y = pos.y;
                go.transform.position = pos;
                go2.transform.position = pos2;
            }
        }
    }

    public static void Points(int points)
    {
        Score = Score + points;
        Debug.Log("Points: " + Score);
    }

    public void SetDefault()
    {
        CurrentState = States.nothing;
    }
    public void TurnBlue()
    {
        IsBlue = true;
    }

    public void Freezed()
    {
        IsFreezed = true;
    }

    public void TurnYellow()
    {
        IsYellow = true;
    }


    //----------

    public void LevelUp()
    {
        if (level == 1)
        {
            RecordHighest();
            SceneManager.LoadScene("Level2");

        }
        if (level == 2)
        {
            RecordHighest();
            SceneManager.LoadScene("Level3");

        }
        if (level == 3)
        {
            RecordHighest();
            SceneManager.LoadScene("End");

        }
        Score = 0;
    }

    public void RecordHighest()
    {
        if (level == 1)
        {
            if (PlayerPrefs.HasKey("LevelOneHighest"))
            {
                if (Score > PlayerPrefs.GetInt("LevelOneHighest"))
                {
                    PlayerPrefs.SetInt("LevelOneHighest", Score);
                }
            }
            else
            {
                PlayerPrefs.SetInt("LevelOneHigest", Score);
            }
        }
        if (level == 2)
        {
            if (PlayerPrefs.HasKey("LevelTwoHighest"))
            {
                if (Score > PlayerPrefs.GetInt("LevelTwoHighest"))
                {
                    PlayerPrefs.SetInt("LevelTwoHighest", Score);
                }
            }
            else
            {
                PlayerPrefs.SetInt("LevelTwoHigest", Score);
            }
        }
        if (level == 3)
        {
            if (PlayerPrefs.HasKey("LevelThreeHighest"))
            {
                if (Score > PlayerPrefs.GetInt("LevelThreeHighest"))
                {
                    PlayerPrefs.SetInt("LevelThreeHighest", Score);
                }
            }
            else
            {
                PlayerPrefs.SetInt("LevelThreeHigest", Score);
            }

        }
    }

    public void GetCurrentScene()
    {
        string currentScene = SceneManager.GetActiveScene().name;
        if (currentScene.Equals("Level1")) { level = 1; }
        if (currentScene.Equals("Level2")) { level = 2; }
        if (currentScene.Equals("Level3")) { level = 3; }
    }

    public void UpdateGUI()
    {
        uitTotalScore.text = "Score: " + Score.ToString();
        uitLife.text = "Life: " + life;
        RecordHighest();
        UpdateHighest();
    }

    public void ClearScore()
    {
        if (level == 1)
        {
            PlayerPrefs.SetInt("LevelOneHighest", -1);
        }
        if (level == 2)
        {
            PlayerPrefs.SetInt("LevelTwoHighest", -1);
        }
        if (level == 3)
        {
            PlayerPrefs.SetInt("LevelThreeHighest", -1);
        }
    }


    public void UpdateHighest()
    {
        if (level == 1)
        {
            if (!PlayerPrefs.HasKey("LevelOneHighest"))
            {
                PlayerPrefs.SetInt("LevelOneHighest", -1);
            }

            if (PlayerPrefs.GetInt("LevelOneHighest") == -1)
            {
                uitHighestScore.text = "No Record";
            }
            else
            {
                uitHighestScore.text = "High Score: " + PlayerPrefs.GetInt("LevelOneHighest").ToString();
            }
        }

        if (level == 2)
        {


            if (!PlayerPrefs.HasKey("LevelTwoHighest"))
            {
                PlayerPrefs.SetInt("LevelTwoHighest", -1);
            }

            if(PlayerPrefs.GetInt("LevelTwoHighest") == -1)
            {
                uitHighestScore.text = "No Record !";
            }
            else
            {
                uitHighestScore.text = "Highest: " + PlayerPrefs.GetInt("LevelTwoHighest").ToString();
            }
        }

        if (level == 3)
        {
            if (!PlayerPrefs.HasKey("LevelThreeHighest"))
            {
                PlayerPrefs.SetInt("LevelThreeHighest", -1);
            }

            if (PlayerPrefs.GetInt("LevelThreeHighest") == -1)
            {
                uitHighestScore.text = "No Record !";
            }
            else
            {
                uitHighestScore.text = "Highest: " + PlayerPrefs.GetInt("LevelThreeHighest").ToString();
            }
        }
    }
}
