﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DotSpeedUp : Dot1 {
	//private float tempspeed;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	public override void OnTriggerEnter (Collider other)
	{
		//tempspeed = Pacman.P.speed;
		base.OnTriggerEnter (other);
		Pacman.P.speed = 2f;
		Invoke ("UnSpeedUp",5);
	}

	public void UnSpeedUp(){
		Pacman.P.speed = 1f;
	//	Destroy (this.gameObject);
	}
}
