﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DotEatGhost : Dot1 {

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	public override void OnTriggerEnter (Collider other)
	{	
		if ((other.gameObject.tag == "Pacman")) {
			base.OnTriggerEnter (other);
			MainCamera.CurrentState = States.eatyellowdot;
			GameObject[] AllGhost = GameObject.FindGameObjectsWithTag ("Ghost");
			foreach (GameObject ghost in AllGhost) {
				ghost.gameObject.tag = "WeakGhost";
			} 
			Invoke ("RegularGhostandDestroy", 5);
		}
	}

	public void RegularGhostandDestroy(){
		GameObject[] AllWeakGhost = GameObject.FindGameObjectsWithTag ("WeakGhost");
		foreach (GameObject ghost in AllWeakGhost) {
			ghost.gameObject.tag="Ghost";
		} 
		//Destroy (this.gameObject);
	}



}
