﻿using UnityEngine;

public class Blinky : Ghost {

    public Transform[] waypoints;
    private Transform currentWaypoint;
    private int index;

    // Use this for initialization
    void Start () {
        if (waypoints.Length > 0) {
            currentWaypoint = waypoints[0];
        }
    }
	
	// Update is called once per frame
	void Update () {
        Move();
	}

    public override void Move() {
		if(MainCamera.IsFreezed == false){
        Vector3 currPos = transform.position;
        Vector3 nextPos = currentWaypoint.position;

        if (Vector3.Distance(currPos, nextPos) > .05f) {
            Vector3 direction = nextPos - currPos;
            direction.Normalize();

            transform.Translate(direction.x * speed * Time.deltaTime,
                                     direction.y * speed * Time.deltaTime,
                                     0,
                                     Space.World);
        }
        else {
            index++;
            if (index == waypoints.Length) {
                index = 0;
            }
            currentWaypoint = waypoints[index];
        }
    
	}else{
		Vector3 pos = transform.position;
		transform.position = pos;
	}
}
}