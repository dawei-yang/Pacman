﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Dot1 : MonoBehaviour {
	protected int score = 0;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
	virtual public void OnTriggerEnter(Collider other){
		if (other.gameObject.tag == "Pacman") {
			this.gameObject.SetActive (false);
			MainCamera.Points (this.score);
			Invoke("DestroyDots",5);
		}
	}

	void DestroyDots(){
		Destroy(this.gameObject);
	}

}
