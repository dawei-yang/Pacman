﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// base class for all pickups
// pickup dies after set period
// is deleted after onTrigger with Pacman
public class Fruit : Dot {
	int points = 100;
    [Header("Set in Inspector")]
    public float lifeTime = 6f;
    public float fadeTime = 4f;

    [Header("Set Dynamically")]
    public float birthTime;

	// Use this for initialization
	void Awake () {
        birthTime = Time.time;
	}
	
	// Update is called once per frame
	void Update () {
        float timeLeft = (Time.time - (birthTime + lifeTime)) / fadeTime;

        if(timeLeft >= 1) {
            Destroy(this.gameObject);
            return;
        }
	}

    override public void OnTriggerEnter(Collider other) {
        if (other.gameObject.tag == "Pacman") {
            //this.gameObject.SetActive(false);
            MainCamera.Points(this.points);
            Destroy(this.gameObject);
            return;
        }
    }
}
