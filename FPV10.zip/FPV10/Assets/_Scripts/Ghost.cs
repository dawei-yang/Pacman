﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Ghost : MonoBehaviour {
	public Material[] materials;
	public Color[] originalColors;
	public bool showBlue = false;
	[Header("Set in Inspector")]
	public float speed = 3f;
	//public float gameRestartDelay = 2f;
	public float leftAndRightEdge = 10f;

	void Awake(){
		
		materials = Utils.GetAllMaterials (gameObject);
		originalColors = new Color[materials.Length];
		for (int i = 0; i < materials.Length; i++) {
			originalColors [i] = materials [i].color;
		}
	}

	// Use this for initialization
	void Start () {
        
	}
	
	// Update is called once per frame
	void Update () {
		if (MainCamera.IsBlue == true) {
			ShowColor ();
		}

        Move();
	}

    public virtual void Move() {
        if (MainCamera.IsFreezed == false) {
            Vector3 pos = transform.position;
            pos.x += speed * Time.deltaTime;
            transform.position = pos;
            if (pos.x < -leftAndRightEdge) {
                //move right
                speed = Mathf.Abs(speed);
            }
            else if (pos.x > leftAndRightEdge) {
                //move left
                speed = -Mathf.Abs(speed);
            }
        }
        else {
            Vector3 pos = transform.position;
            transform.position = pos;
        }
    }


	public void ShowColor(){
		foreach (Material m in materials) {
			m.color = Color.blue;
		}
		MainCamera.IsBlue = false;
		Invoke ("UnShowColor", 5);
	}

	public void UnShowColor(){
		for (int i = 0; i < materials.Length; i++) {
			materials [i].color = originalColors [i];
		}
	
	}


}
