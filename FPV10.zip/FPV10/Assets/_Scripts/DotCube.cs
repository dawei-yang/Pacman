﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DotCube : Dot1 {

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}


	public override void OnTriggerEnter (Collider other)
	{	base.OnTriggerEnter(other);
		if ((other.gameObject.tag == "Pacman")) {
				MainCamera.IsFreezed = true;
				MainCamera.IsBlue = true;
		
			MainCamera.CurrentState = States.eatcubedot;
			Invoke ("UnFreezedandDestroy", 5);
		}
	}

	public void UnFreezedandDestroy(){
		MainCamera.IsFreezed = false;
		Destroy (this.gameObject);
	}


}
