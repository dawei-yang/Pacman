﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Dot : MonoBehaviour
{
    [Header("Set in Inspector")]
    public int points = 0;

    virtual public void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "Pacman")
        {
            MainCamera.Points(this.points);

            Destroy(gameObject);
            return;
        }
    }
}